
/**
 * Write a description of interface IDisplay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface IDisplay
{
   String muestraResultado(float res);
   String muestraError(CalculadoraError error);
}
