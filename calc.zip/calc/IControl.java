
/**
 * Write a description of interface IControl here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface IControl
{
    void introduceValorX(int x);
    void introduceValorY(int y);
    void introduceOperacion(Operacion op);
    float igual();
}
