
/**
 * Enumeration class CalculadoraError - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum CalculadoraError
{
    DIV_ZERO, MAX_NUMBER, IMAGINARIO
}
