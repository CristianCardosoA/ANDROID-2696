
/**
 * Write a description of interface IProcesamiento here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface IProcesamiento
{
    float suma(float x, float y);
    float resta(float x, float y);
    float multi(float x, float y);
    float div(float x, float y);
}
